package org.example.Entities;

import java.awt.image.BufferedImage;

public class Enemy extends Entity{
    public Enemy(int x, int y, BufferedImage img) {
        super(x, y, img);
    }
}
