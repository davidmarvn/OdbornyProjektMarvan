package org.example.Entities;

import javax.swing.*;
import java.awt.image.BufferedImage;

public class Player extends Entity{

    private boolean right = false, up = false, down = false, left = false;
    private static int PLAYER_STEPS = 6;
    private boolean canMove = true;
    private int moveDelay;
    private boolean moved = false;


    public Player(int tileX, int tileY, BufferedImage img) {
        super(tileX, tileY,img);
    }

    public void update(){
        moveDelay+=2;
        if (moveDelay <= 200){
            canMove = false;
        }
        else{
            canMove = true;
        }
    }

    public void setCanMove(boolean canMove) {
        this.canMove = canMove;
    }

    public boolean getCanMove() {
        return canMove;
    }

    public void resetMoveDelay(){
        moveDelay = 0;
    }

    public boolean isIn(){
        if (getTileX() < 7 || getTileX() > 0 || getTileY() < 7 || getTileY() > 0){
            return true;
        }
        return false;
    }

    public boolean isMoved() {
        return moved;
    }

    public void setMoved(boolean moved) {
        this.moved = moved;
    }

    public boolean moveFree(){
        return getCanMove() || !isMoved();
    }
}
