package org.example.Entities;

import org.example.graphics.Tile;
import org.example.help.Direction;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Entity {

    private int width;
    private int height;
    private BufferedImage Image;
    private Rectangle hitBox;
    private final int STEPS = 10;
    private Tile tile;
    private int tileX, tileY;

    public Entity(int tileX, int tileY, BufferedImage img) {
        this.Image = img;
        this.tileX = tileX;
        this.tileY = tileY;
        this.width = 86;
        this.height = 86;
    }

    /*public void move(Direction direction){
        switch (direction){
            case RIGHT -> x += STEPS;
            case LEFT -> x -= STEPS;
            case UP -> y -= STEPS;
            case DOWN -> y += STEPS;
        }
    }*/
    public BufferedImage getImage() {
        return Image;
    }

    public void setImage(BufferedImage image) {
        Image = image;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int[][] getTile() {
        return  new int[tileX][tileY];
    }

    public void setTile(Tile tile) {
        this.tile = tile;
    }

    public int getTileX() {
        return tileX;
    }

    public void setTileX(int tileX) {
        this.tileX = tileX;
    }

    public int getTileY() {
        return tileY;
    }

    public void setTileY(int tileY) {
        this.tileY = tileY;
    }
}
