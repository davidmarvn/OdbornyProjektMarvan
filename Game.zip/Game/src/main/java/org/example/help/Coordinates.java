package org.example.help;

public class Coordinates {
}
