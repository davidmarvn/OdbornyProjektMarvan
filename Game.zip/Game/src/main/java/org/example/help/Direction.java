package org.example.help;

public enum Direction {
    UP, LEFT, RIGHT, DOWN
}
