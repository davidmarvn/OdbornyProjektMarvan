package org.example.listeners;

import org.example.Entities.Player;
import org.example.GameLogic;

import java.awt.event.KeyEvent;

public class KeyListener implements java.awt.event.KeyListener {

    private GameLogic logic;
    private Player player;

    public KeyListener(GameLogic logic) {
        this.logic = logic;
        player = logic.getPlayer();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_D -> {
                if (player.isIn() && !player.moveFree()){
                    player.setTileX(player.getTileX() + 1);
                    player.resetMoveDelay();
                    player.setMoved(true);
                }
            }
            case KeyEvent.VK_W -> {
                if (player.isIn() && !player.moveFree()){
                    player.setTileY(player.getTileY() - 1);
                    player.resetMoveDelay();
                    player.setMoved(true);
                }
            }
            case KeyEvent.VK_S -> {
                if (player.isIn() && !player.moveFree()){
                    player.setTileY(player.getTileY() + 1);
                    player.resetMoveDelay();
                    player.setMoved(true);
                }
            }
            case KeyEvent.VK_A -> {
                if (player.isIn() && !player.moveFree()){
                    player.setTileX(player.getTileX() - 1);
                    player.resetMoveDelay();
                    player.setMoved(true);
                }
            }
            case KeyEvent.VK_ESCAPE -> System.exit(0);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_A ->player.setMoved(false);
            case KeyEvent.VK_W ->player.setMoved(false);
            case KeyEvent.VK_S ->player.setMoved(false);
            case KeyEvent.VK_D ->player.setMoved(false);
        }
    }
}
