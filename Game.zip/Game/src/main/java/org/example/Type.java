package org.example;

public enum Type {
    PAWN, ROOK, KNIGHT, BISHOP, QUEEN
}
