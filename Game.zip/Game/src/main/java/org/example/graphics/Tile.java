package org.example.graphics;

public class Tile {

    private int x;
    private int y;

    public Tile() {

    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
