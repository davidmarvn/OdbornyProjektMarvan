package org.example.graphics;

import org.example.GameGraphics;

import java.awt.image.BufferedImage;

public class ChessBoard {

    public int[][] tiles;
    private BufferedImage image;
    private GameGraphics graphics;
    private int x;
    private int y;
    private int height;
    private int width;


    public ChessBoard(BufferedImage image, GameGraphics graphics) {
        this.image = image;
        this.tiles = new int[7][7];
        this.graphics = graphics;
        this.height = 688;
        this.width = 688;

    }
    public BufferedImage getImage() {
        return image;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
}
