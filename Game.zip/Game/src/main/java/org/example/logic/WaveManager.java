package org.example.logic;

public class WaveManager {

    private int timeLimit;
    private long spawnLimit;

}
