package org.example.logic;

public class Wave {
}
