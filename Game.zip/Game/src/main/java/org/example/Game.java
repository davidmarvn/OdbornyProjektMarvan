package org.example;

import org.example.Entities.Enemy;
import org.example.Entities.Player;

import java.util.ArrayList;

public class Game {

    public Player player;
    private GameLogic logic;
    private GameGraphics gameGraphics;

    private ArrayList<Enemy> enemies;

    final double TILE_WIDTH = 85;


    public Game() {
        this.player = new Player(0,0,null);
        initClasses();


        run();
    }


    private void update() {
        player.update();
    }

    private void initClasses() {
        this.logic = new GameLogic();
        this.gameGraphics = new GameGraphics(logic);
        enemies = new ArrayList<>();
        logic.initialize();
    }

    public void run() {


        double timePerFrame = logic.SECOND_IN_NANO / logic.FINAL_FPS;
        double timePerUpdate = logic.SECOND_IN_NANO / logic.FINAL_UPS;

        long previousTime = System.nanoTime();
        double deltaU = 0;
        double deltaF = 0;

        int frames = 0;
        int updates = 0;
        long lastCheck = System.currentTimeMillis();

        while (true) {

            long currentTime = System.nanoTime();

            deltaU += (currentTime - previousTime) / timePerUpdate;
            deltaF += (currentTime - previousTime) / timePerFrame;

            previousTime = currentTime;

            //"1" = one second
            if (deltaU >= 1) {
                update();
                updates++;
                deltaU--;
            }

            //"1" = one second
            if (deltaF >= 1) {
                gameGraphics.updateGraphics(logic);
                frames++;
                deltaF--;

            }

            if (System.currentTimeMillis() - lastCheck >= logic.SECOND_IN_MILI) {
                lastCheck = System.currentTimeMillis();
                System.out.println(frames + "      " + updates);
                frames = 0;
                updates = 0;
            }
        }
    }

    private void render(){

    }

    private void loose() {

    }

    private void win() {

    }
}
