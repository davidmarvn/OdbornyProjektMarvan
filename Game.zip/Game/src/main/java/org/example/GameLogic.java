package org.example;


import org.example.Entities.Player;

public class GameLogic {

    private Player player;
    final int FINAL_FPS = 120;
    final int FINAL_UPS = 200;
    final double SECOND_IN_NANO = 1000000000.0;
    final double SECOND_IN_MILI = 1000.0;


    public GameLogic() {
        player = new Player(0,0, null);
    }

    public Player getPlayer() {
        return player;
    }
    public void initialize(){

    }
}
