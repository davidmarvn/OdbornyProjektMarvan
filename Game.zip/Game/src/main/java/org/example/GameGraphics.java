package org.example;

import org.example.Entities.Player;
import org.example.graphics.ChessBoard;
import org.example.listeners.KeyListener;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class GameGraphics extends JFrame {

    public GameLogic gameLogic;
    private KeyListener keyListener;
    private Player player;
    private ChessBoard chessBoard;
    private Dimension screenSize;
    private int tileWidth;

    public GameGraphics(GameLogic gameLogic) {
        this.gameLogic = gameLogic;
        this.keyListener = new KeyListener(gameLogic);
        chessBoard = new ChessBoard(GameGraphics.loadImage("background.png"), this);
        player = gameLogic.getPlayer();
        this.screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        setSize(screenSize);
        setResizable(false);
        setLocationRelativeTo(null);
        add(new Draw());
        setImages();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);


        addKeyListener(keyListener);
        chessBoard.setX((screenSize.width - chessBoard.getWidth()) / 2);
        chessBoard.setY((screenSize.height - chessBoard.getHeight()) / 2);

        //fullScreen();
    }

    public void updateGraphics(GameLogic logic) {
        this.gameLogic = logic;
        repaint();
    }


    public class Draw extends JPanel{

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            BufferedImage scaledPlayerImg = new BufferedImage(player.getWidth(),player.getHeight(),player.getImage().getType());

            Graphics2D g2d = scaledPlayerImg.createGraphics();
            g2d.drawImage(player.getImage(), player.getTileX(), player.getTileY(), player.getWidth(), player.getHeight(), null);
            g2d.dispose();

            //CHESSBOARD
            g.drawImage(chessBoard.getImage(), chessBoard.getX(), chessBoard.getY(), chessBoard.getWidth(), chessBoard.getHeight(), null);

            //PLAYER
            g.drawImage(scaledPlayerImg, chessBoard.getX() + (player.getTileX() * 85), chessBoard.getY() + (player.getTileY() * 85),this);

        }
    }

    public static BufferedImage loadImage(String imageName){
        BufferedImage img;

        try{
            img = ImageIO.read(new File("src/main/resources/" + imageName));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return img;
    }

    public BufferedImage assignImage(int positionX, int positionY){
        BufferedImage sprite = loadImage("mainSprite.png");
        BufferedImage img = null;

        for (int j = 0; j <= positionY; j++){
            for (int i = 0; i <= positionX; i++){
                img = sprite.getSubimage(28 * i, 28 * j, 28, 28);
            }
        }
        return img;
    }
    public void setImages(){
        gameLogic.getPlayer().setImage(assignImage(1, 1));
    }

    /*public void fullScreen(){
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice[] devices = ge.getScreenDevices();

        GraphicsDevice device = devices[0];

        setUndecorated(true);
        device.setFullScreenWindow(this);

        DisplayMode mode = device.getDisplayMode();
        setSize(mode.getWidth(), mode.getHeight());

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }*/

    public Dimension getScreenSize() {
        return screenSize;
    }
}
