package org.example;

public enum Direction {
    LEFT, RIGHT, UP, DOWN;
}
